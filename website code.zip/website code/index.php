<html>

<meta name="viewport" content="width=device-width, initial-scale=1">

<body>

  
<head>
     
<meta http-equiv="refresh" content="10">    
   
<title>monitoring</title>
   
<style>
   
   
body
   
{  
    
    
background-color: powderblue;
    
    
background-size: 50% 20%;
    
background-repeat: no-repeat;
    
background-position: center;
    
margin-bottom: 100px;
  
    
   
}
  

h1 

{
    
text-align: center;
color: GREEN;

}


h2 
{
    
text-align: center;
     
color:maroon;
    

}


h3 
{
    
text-align: center;
color: green;
     


} 

p

{
 
color:blueviolet;

}
}

</style>

  
</head>




<?php      
// start php script
// ********************************************database connection *****************************************************  
 	  
 $dbhost = 'localhost';                // db host
	  
 $dbuser = 'myiotuser';            // my sql user name
	  
 $dbpass = 'Prashant007db';            // db password
	  
 $conn = mysql_connect($dbhost, $dbuser, $dbpass);        // connect to sql
	   
	   
if(! $conn ) 
{
		  
die('Could not connect: ' . mysql_error());       // if connection not established the generate erro
	   
}
 	//   echo 'Database Connection successful.<br> ';              
// messege for connection successful
  //
 ****************************************database access*************************************     
     
      
 $sql = 'SELECT pname, s1, s2, s3, s4 ,s5  FROM  `monitor` where pname="pollution" ';     // access sql      
       
mysql_select_db('myiotprojectsdb');            // myiot1 is user name of selected database
	   
$retval = mysql_query( $sql, $conn );
       
       
if(! $retval ) 
{
		  
die('Could not enter data: ' . mysql_error());
	   
}
      
 else
   //      		echo 'Table Retrieval successful.<br> ';
       		

 // ************************display/ show***************************       		
       		
     
  while($row = mysql_fetch_assoc($retval))
       
 {
       
echo 
                 
               
                
 " <h1>Smart City With Automated</h1> ". 
                  
" <h1>Street Light And Smart </h1> ". 
                   
"<h1>Irrigation System Using IOT<h1>".
                  

                  
             
           
             
            
           
 "<h2> SOIL MOISTURE LEVEL   :        
 {$row['s1']} %</h2> ".
 "<h2>POWER CONSUMPTION  :  400 Watt </h2> ";


}
        
       
 mysql_close($conn);


?>








<center><p> <font size="5"<b><u>Presented by</b></u><b>: SALVI RAI, AKANKSHA SINGH & HANISHA YADAV</font></b></p></center>
</body>
</html>