PROJECT
<?php

//   if(isset($_GET['pname']) or isset($_GET['s1'])  or isset($_GET['s2'])  or isset($_GET['s3'])  or isset($_GET['s4']  or isset($_GET['s5']))
   {
	   $temp_pname= $_GET['pname'];
	   $temp_s1 =  $_GET['s1'];
	   $temp_s2 =  $_GET['s2'];
	   $temp_s3 =  $_GET['s3'];
	   $temp_s4 =  $_GET['s4'];
	   $temp_s4 =  $_GET['s5'];
	   
         
	   
	   echo  $temp_pname;
	   echo '<br>';
	   echo  $temp_s1;
	   echo '<br>';
	   echo  $temp_s2 ;
	   echo '<br>';
	   echo  $temp_s3 ;
	   echo '<br>';
	   echo  $temp_s4 ;
	   echo '<br>';
	   echo  $temp_s5 ;
	   
         
	   	
	   
	   
	   $dbhost = 'localhost';
	   $dbuser = 'myiotuser';
	   $dbpass = 'Prashant007db';
	   $conn = mysql_connect($dbhost, $dbuser, $dbpass);
	   
	   if(! $conn ) {
		  die('<br>Could not connect: <br>' . mysql_error());
	   }
	   echo '<br>Database Connected successfully</br>';
	   
	   
	/*   $sql = 'UPDATE `automation` SET `name`=". $humid .",`R1`=". $temp .",`R1`=". $temp ." WHERE 1';    */ 

	  $sql = "UPDATE monitor SET  s1='$temp_s1', s2='$temp_s2', s3='$temp_s3', s4='$temp_s4', s5='$temp_s5'   WHERE pname = 'pollution' ";	
	  				
	   mysql_select_db( 'myiotprojectsdb' );
	   $retval = mysql_query( $sql, $conn );
	   
	   if(! $retval ) {
		  die('<br>Could not enter data: <br>' . mysql_error());
	   }
	   
	   echo "Entered data successfully.\n";
	   
	   if($temp_s1==007)
	   {
	   echo  '<br> you win <br> ';
	   }
	   else
	   {
	   echo '<br> try again';
	   }
	  
	   mysql_close($conn);
   }
   
 ?>